import { GoogleGenAI, Type } from "@google/genai";
import { ProductSuggestion } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Identifies a product based on a barcode string using Google Search Grounding.
 */
export const identifyProductByBarcode = async (barcode: string): Promise<ProductSuggestion | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Identifique o produto com o código de barras "${barcode}". Retorne apenas o nome comum do produto e sua categoria geral (ex: Laticínios, Bebidas, Higiene).`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING, description: "O nome comercial do produto" },
            category: { type: Type.STRING, description: "A categoria do produto" }
          },
          required: ["name", "category"]
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) return null;
    return JSON.parse(jsonText) as ProductSuggestion;

  } catch (error) {
    console.error("Erro ao identificar produto por código de barras:", error);
    return null;
  }
};

/**
 * Identifies a product from an image (simulating a barcode scan or product photo).
 */
export const identifyProductByImage = async (base64Image: string): Promise<ProductSuggestion | null> => {
  try {
    // Remove header data if present (data:image/jpeg;base64,)
    const cleanBase64 = base64Image.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: cleanBase64
            }
          },
          {
            text: "Analise esta imagem. Identifique qual é o produto (nome comercial) e sua categoria (ex: Laticínios, Limpeza, Hortifruti). Se for um código de barras, tente lê-lo para identificar o produto."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING, description: "O nome exato do produto identificado na imagem." },
            category: { type: Type.STRING, description: "A categoria geral do produto." }
          },
          required: ["name", "category"]
        }
      }
    });
    
    const text = response.text;
    if (!text) return null;
    
    return JSON.parse(text) as ProductSuggestion;

  } catch (error) {
    console.error("Erro ao identificar produto por imagem:", error);
    return null;
  }
};