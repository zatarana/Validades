import { Product } from '../types';

const NOTIFICATION_KEY = 'validade_ai_last_notification';

/**
 * Solicita permissão ao usuário para enviar notificações.
 */
export const requestNotificationPermission = async (): Promise<NotificationPermission> => {
  if (!('Notification' in window)) {
    console.warn('Este navegador não suporta notificações.');
    return 'denied';
  }
  
  const permission = await Notification.requestPermission();
  return permission;
};

/**
 * Verifica o estado da permissão atual.
 */
export const getNotificationPermission = (): NotificationPermission => {
  if (!('Notification' in window)) return 'denied';
  return Notification.permission;
};

/**
 * Envia uma notificação do sistema.
 */
const sendNotification = (title: string, body: string) => {
  if (Notification.permission === 'granted') {
    // Tenta usar o Service Worker para notificação (melhor para mobile/PWA)
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.ready.then(registration => {
        registration.showNotification(title, {
          body,
          icon: './icon.svg',
          badge: './icon.svg',
          vibrate: [200, 100, 200],
          tag: 'expiration-alert' // Substitui notificações anteriores com a mesma tag
        } as any);
      });
    } else {
      // Fallback para notificação padrão de API
      new Notification(title, {
        body,
        icon: './icon.svg',
      });
    }
  }
};

/**
 * Verifica produtos e envia notificação se necessário.
 * Lógica: Envia apenas uma vez por dia para evitar spam, a menos que forçado.
 */
export const checkAndNotifyExpirations = (products: Product[], force: boolean = false) => {
  if (Notification.permission !== 'granted' || products.length === 0) return;

  const todayStr = new Date().toLocaleDateString();
  const lastSent = localStorage.getItem(NOTIFICATION_KEY);

  // Se já enviou hoje e não é forçado, ignora
  if (!force && lastSent === todayStr) {
    return;
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let expiredCount = 0;
  let expiringSoonCount = 0; // Próximos 3 dias

  products.forEach(p => {
    const expDate = new Date(p.expirationDate);
    expDate.setHours(0, 0, 0, 0);
    
    const diffTime = expDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      expiredCount++;
    } else if (diffDays >= 0 && diffDays <= 3) {
      expiringSoonCount++;
    }
  });

  if (expiredCount > 0 || expiringSoonCount > 0) {
    let title = '⚠️ Alerta de Validade';
    let body = '';

    if (expiredCount > 0 && expiringSoonCount > 0) {
      body = `Você tem ${expiredCount} produto(s) vencido(s) e ${expiringSoonCount} vencendo em breve!`;
    } else if (expiredCount > 0) {
      body = `Atenção! ${expiredCount} produto(s) já venceram. Verifique sua despensa.`;
    } else {
      body = `Fique atento! ${expiringSoonCount} produto(s) vão vencer nos próximos 3 dias.`;
    }

    sendNotification(title, body);
    localStorage.setItem(NOTIFICATION_KEY, todayStr);
  }
};