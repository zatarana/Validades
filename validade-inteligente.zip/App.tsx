import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Filter, SortAsc, SortDesc, Search, Calendar, Info, FileText, Download, WifiOff, Settings, Layers, Bell, BellOff, BellRing } from 'lucide-react';
import { Product, SortOption, FilterStatus } from './types';
import { saveProducts, loadProducts } from './services/storage';
import { checkAndNotifyExpirations, requestNotificationPermission, getNotificationPermission } from './services/notifications';
import { ProductCard } from './components/ProductCard';
import { AddProductModal } from './components/AddProductModal';
import { StatsOverview } from './components/StatsOverview';
import { SettingsModal } from './components/SettingsModal';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>(SortOption.EXPIRATION_ASC);
  const [filterStatus, setFilterStatus] = useState<FilterStatus>(FilterStatus.ALL);
  const [showFilters, setShowFilters] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');

  // Monitor online status
  useEffect(() => {
    const handleStatusChange = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);
    return () => {
      window.removeEventListener('online', handleStatusChange);
      window.removeEventListener('offline', handleStatusChange);
    };
  }, []);

  // Load initial data and check notifications
  useEffect(() => {
    const loaded = loadProducts();
    // Migration: Ensure all loaded products have a quantity property
    const productsWithQuantity = loaded.map(p => ({
      ...p,
      quantity: p.quantity || 1
    }));
    
    setProducts(productsWithQuantity);
    
    // Check permission status
    setNotificationPermission(getNotificationPermission());

    // Check for expirations shortly after load (gives UI time to render)
    const timer = setTimeout(() => {
      checkAndNotifyExpirations(productsWithQuantity);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  // Save on change
  useEffect(() => {
    saveProducts(products);
  }, [products]);

  const handleNotificationClick = async () => {
    if (notificationPermission === 'granted') {
      // Just test notification if already granted
      checkAndNotifyExpirations(products, true); // Force a test notification
      alert('Notificações estão ativas! Um teste foi enviado.');
    } else if (notificationPermission === 'denied') {
      alert('As notificações estão bloqueadas pelo navegador. Por favor, habilite-as nas configurações do site.');
    } else {
      const result = await requestNotificationPermission();
      setNotificationPermission(result);
      if (result === 'granted') {
        checkAndNotifyExpirations(products, true);
      }
    }
  };

  const handleAddProduct = (newProductData: Omit<Product, 'id' | 'addedAt'>) => {
    const normalizedName = newProductData.name.trim().toLowerCase();
    
    // Check for duplicates (Same name AND same expiration date)
    const existingProductIndex = products.findIndex(p => 
      p.name.trim().toLowerCase() === normalizedName && 
      p.expirationDate === newProductData.expirationDate
    );

    if (existingProductIndex >= 0) {
      const existingProduct = products[existingProductIndex];
      const confirmMerge = window.confirm(
        `O produto "${existingProduct.name}" com validade ${new Date(existingProduct.expirationDate).toLocaleDateString('pt-BR')} já existe na lista.\n\nDeseja apenas aumentar a quantidade para ${existingProduct.quantity + 1}?`
      );

      if (confirmMerge) {
        setProducts(prev => {
          const updated = [...prev];
          updated[existingProductIndex] = {
            ...existingProduct,
            quantity: (existingProduct.quantity || 1) + 1
          };
          return updated;
        });
        return; // Stop here, don't create new ID
      }
    }

    // If no duplicate or user chose not to merge
    const newProduct: Product = {
      ...newProductData,
      id: crypto.randomUUID(),
      addedAt: Date.now(),
      quantity: newProductData.quantity || 1
    };

    setProducts((prev) => [...prev, newProduct]);
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('Tem certeza que deseja remover este produto?')) {
      setProducts((prev) => prev.filter((p) => p.id !== id));
    }
  };

  const handleImportProducts = (importedProducts: Product[]) => {
    if (window.confirm('Isso substituirá sua lista atual pelos dados do backup. Deseja continuar?')) {
      // Ensure imported products have quantity
      const normalizedImports = importedProducts.map(p => ({
        ...p,
        quantity: p.quantity || 1
      }));
      setProducts(normalizedImports);
    }
  };

  const handleClearAll = () => {
    setProducts([]);
  };

  const handleExportReport = () => {
    if (products.length === 0) {
      alert("Não há produtos para gerar relatório.");
      return;
    }

    // CSV Header
    const headers = ['Nome', 'Quantidade', 'Data de Validade', 'Categoria', 'Data Adição', 'Código de Barras', 'Status', 'Dias Restantes'];
    
    // CSV Rows
    const rows = products.map(p => {
      const today = new Date();
      today.setHours(0,0,0,0);
      const exp = new Date(p.expirationDate);
      exp.setHours(0,0,0,0);
      const diffDays = Math.ceil((exp.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      let status = 'Válido';
      if (diffDays < 0) status = 'Vencido';
      else if (diffDays <= 7) status = 'Atenção';

      return [
        `"${p.name.replace(/"/g, '""')}"`,
        p.quantity || 1,
        p.expirationDate,
        `"${(p.category || '').replace(/"/g, '""')}"`,
        new Date(p.addedAt).toLocaleDateString('pt-BR'),
        `"${(p.barcode || '')}"`,
        status,
        diffDays
      ].join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(',') + "\n" 
      + rows.join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `validade_produtos_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // First, filter and sort locally based on user preference
  const filteredAndSortedProducts = useMemo(() => {
    let result = [...products];

    // Filter by Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.barcode?.includes(q) ||
          p.category?.toLowerCase().includes(q)
      );
    }

    // Filter by Status
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (filterStatus !== FilterStatus.ALL) {
      result = result.filter((p) => {
        const expDate = new Date(p.expirationDate);
        expDate.setHours(0, 0, 0, 0);
        const diffDays = Math.ceil((expDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

        if (filterStatus === FilterStatus.EXPIRED) return diffDays < 0;
        if (filterStatus === FilterStatus.WARNING) return diffDays >= 0 && diffDays <= 7;
        if (filterStatus === FilterStatus.GOOD) return diffDays > 7;
        return true;
      });
    }

    // Sort
    result.sort((a, b) => {
      const dateA = new Date(a.expirationDate).getTime();
      const dateB = new Date(b.expirationDate).getTime();

      switch (sortOption) {
        case SortOption.EXPIRATION_ASC:
          return dateA - dateB;
        case SortOption.EXPIRATION_DESC:
          return dateB - dateA;
        case SortOption.NAME_ASC:
          return a.name.localeCompare(b.name);
        case SortOption.ADDED_DATE_DESC:
          return b.addedAt - a.addedAt;
        default:
          return 0;
      }
    });

    return result;
  }, [products, searchQuery, sortOption, filterStatus]);

  // Then group by category
  const groupedProducts = useMemo(() => {
    const groups: Record<string, Product[]> = {};
    
    filteredAndSortedProducts.forEach(product => {
      const cat = product.category ? product.category.trim() : "";
      const key = cat === "" ? "Sem Categoria" : cat;
      
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(product);
    });

    return groups;
  }, [filteredAndSortedProducts]);

  const sortedCategories = useMemo(() => {
    return Object.keys(groupedProducts).sort((a, b) => {
      if (a === "Sem Categoria") return 1; // Put Uncategorized at bottom
      if (b === "Sem Categoria") return -1;
      return a.localeCompare(b);
    });
  }, [groupedProducts]);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Offline Banner */}
      {!isOnline && (
        <div className="bg-gray-800 text-white text-xs py-1 px-4 text-center flex items-center justify-center gap-2">
          <WifiOff className="w-3 h-3" />
          <span>Você está offline. O app funciona, mas a IA não estará disponível.</span>
        </div>
      )}

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-brand-600 p-2 rounded-lg">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">Validade.ai</h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleNotificationClick}
              className={`p-2 rounded-full transition-colors relative ${
                notificationPermission === 'granted' 
                  ? 'text-brand-600 hover:bg-brand-50' 
                  : notificationPermission === 'denied'
                    ? 'text-gray-300 cursor-not-allowed'
                    : 'text-gray-500 hover:bg-gray-100'
              }`}
              title={
                notificationPermission === 'granted' 
                  ? 'Notificações Ativadas (Toque para testar)' 
                  : 'Ativar notificações'
              }
            >
              {notificationPermission === 'granted' ? (
                <BellRing className="w-6 h-6" />
              ) : notificationPermission === 'denied' ? (
                <BellOff className="w-6 h-6" />
              ) : (
                <>
                  <Bell className="w-6 h-6" />
                  <span className="absolute top-1.5 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                </>
              )}
            </button>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors"
              title="Configurações"
            >
              <Settings className="w-6 h-6" />
            </button>
            <button 
              onClick={handleExportReport}
              className="hidden md:flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              title="Gerar Relatório CSV"
            >
              <Download className="w-4 h-4" />
              Relatório
            </button>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="md:hidden bg-brand-600 text-white p-2 rounded-full shadow-lg hover:bg-brand-700 transition-colors"
            >
              <Plus className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6">
        <StatsOverview products={products} />

        {/* Controls */}
        <div className="mb-6 space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar produto..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none shadow-sm"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-4 py-2 rounded-xl border flex items-center gap-2 transition-colors ${
                showFilters ? 'bg-brand-50 border-brand-200 text-brand-700' : 'bg-white border-gray-200 text-gray-600'
              }`}
            >
              <Filter className="w-5 h-5" />
            </button>
            {/* Mobile Report Button */}
            <button
               onClick={handleExportReport}
               className="md:hidden px-4 py-2 rounded-xl border border-gray-200 bg-white text-gray-600 flex items-center justify-center"
               title="Gerar Relatório"
            >
              <FileText className="w-5 h-5" />
            </button>
          </div>

          {showFilters && (
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 animate-in slide-in-from-top-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 mb-2 uppercase">Ordenar por</label>
                  <select
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value as SortOption)}
                    className="w-full p-2 border border-gray-200 rounded-lg text-sm outline-none focus:border-brand-500"
                  >
                    <option value={SortOption.EXPIRATION_ASC}>Validade (Mais próxima)</option>
                    <option value={SortOption.EXPIRATION_DESC}>Validade (Mais distante)</option>
                    <option value={SortOption.NAME_ASC}>Nome (A-Z)</option>
                    <option value={SortOption.ADDED_DATE_DESC}>Adicionado recentemente</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 mb-2 uppercase">Filtrar Status</label>
                  <div className="flex gap-2">
                    {[
                      { label: 'Todos', value: FilterStatus.ALL },
                      { label: 'Atenção', value: FilterStatus.WARNING },
                      { label: 'Vencidos', value: FilterStatus.EXPIRED },
                    ].map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => setFilterStatus(opt.value)}
                        className={`flex-1 py-2 text-sm rounded-lg border transition-colors ${
                          filterStatus === opt.value
                            ? 'bg-brand-50 border-brand-200 text-brand-700 font-medium'
                            : 'bg-gray-50 border-transparent text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Product List Grouped by Category */}
        <div className="space-y-6">
          {filteredAndSortedProducts.length === 0 ? (
            <div className="text-center py-12">
              <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Info className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900">Nenhum produto encontrado</h3>
              <p className="text-gray-500 mt-1">Adicione produtos ou ajuste seus filtros.</p>
            </div>
          ) : (
            sortedCategories.map(category => (
              <div key={category} className="space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-500">
                <div className="flex items-center gap-2 px-1">
                  <div className="bg-brand-100 p-1.5 rounded text-brand-600">
                    <Layers className="w-4 h-4" />
                  </div>
                  <h2 className="text-base font-bold text-gray-800 uppercase tracking-wide text-xs">
                    {category}
                    <span className="ml-2 text-gray-400 font-normal normal-case">
                      ({groupedProducts[category].length})
                    </span>
                  </h2>
                </div>
                <div className="space-y-3">
                  {groupedProducts[category].map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onDelete={handleDeleteProduct}
                    />
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </main>

      {/* Floating Action Button (Desktop) */}
      <button
        onClick={() => setIsModalOpen(true)}
        className="hidden md:flex fixed bottom-8 right-8 bg-brand-600 text-white p-4 rounded-full shadow-xl hover:bg-brand-700 transition-all hover:scale-105 z-20 group"
      >
        <Plus className="w-6 h-6" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 transition-all duration-300 ease-in-out whitespace-nowrap">
          Novo Produto
        </span>
      </button>

      {/* Floating Action Button (Mobile - Sticky) */}
      <div className="md:hidden fixed bottom-6 right-6 z-20">
         <button
            onClick={() => setIsModalOpen(true)}
            className="bg-brand-600 text-white w-14 h-14 rounded-full shadow-xl hover:bg-brand-700 transition-transform active:scale-95 flex items-center justify-center"
          >
            <Plus className="w-8 h-8" />
          </button>
      </div>

      <AddProductModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddProduct}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        products={products}
        onImport={handleImportProducts}
        onClear={handleClearAll}
      />
    </div>
  );
};

export default App;