import React, { useState } from 'react';
import { Product } from '../types';
import { Trash2, AlertTriangle, CheckCircle, Calendar, Tag, Clock, ChevronDown } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onDelete: (id: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onDelete }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expDate = new Date(product.expirationDate);
  expDate.setHours(0, 0, 0, 0);

  const diffTime = expDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  let statusColor = "bg-white border-gray-200";
  let badgeColor = "bg-green-100 text-green-800";
  let statusText = `${diffDays} dias restantes`;

  if (diffDays < 0) {
    statusColor = "bg-red-50 border-red-200";
    badgeColor = "bg-red-100 text-red-800";
    statusText = `Venceu há ${Math.abs(diffDays)} dias`;
  } else if (diffDays === 0) {
    statusColor = "bg-red-50 border-red-200";
    badgeColor = "bg-red-100 text-red-800";
    statusText = "Vence hoje!";
  } else if (diffDays <= 7) {
    statusColor = "bg-orange-50 border-orange-200";
    badgeColor = "bg-orange-100 text-orange-800";
    statusText = `Vence em ${diffDays} dias`;
  }

  const formattedDate = expDate.toLocaleDateString('pt-BR');
  
  // Format added date
  const addedDate = new Date(product.addedAt);
  const formattedAddedDate = addedDate.toLocaleDateString('pt-BR');

  const quantity = product.quantity || 1;

  return (
    <div 
      onClick={() => setIsExpanded(!isExpanded)}
      className={`relative p-4 rounded-xl border shadow-sm transition-all duration-300 hover:shadow-md cursor-pointer ${statusColor} flex flex-col`}
    >
      <div className="flex justify-between items-start">
        <div className="flex-1 pr-8">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold text-gray-900 line-clamp-2">{product.name}</h3>
            {quantity > 1 && (
              <span className="bg-gray-800 text-white text-xs font-bold px-2 py-0.5 rounded-full flex-shrink-0">
                x{quantity}
              </span>
            )}
          </div>
          
          <div className="flex flex-wrap items-center gap-2 mt-2">
            <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${badgeColor}`}>
              {statusText}
            </span>
            {product.category && (
               <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">
                {product.category}
              </span>
            )}
          </div>

          {/* Primary Info Always Visible */}
          <div className="flex items-center gap-1.5 mt-2 text-sm text-gray-700" title="Data de Validade">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span className="font-semibold">Validade: {formattedDate}</span>
          </div>
        </div>

        {/* Actions & Chevron */}
        <div className="flex flex-col items-end gap-3 absolute top-4 right-4">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onDelete(product.id);
            }}
            className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors z-10"
            aria-label="Excluir produto"
          >
            <Trash2 className="w-5 h-5" />
          </button>
          
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
        </div>
      </div>

      {/* Expandable Section */}
      <div 
        className={`grid transition-[grid-template-rows,opacity,margin,padding] duration-300 ease-in-out ${
          isExpanded 
            ? 'grid-rows-[1fr] opacity-100 mt-3 pt-3 border-t border-gray-200/50' 
            : 'grid-rows-[0fr] opacity-0 mt-0 pt-0 border-none'
        }`}
      >
        <div className="overflow-hidden min-h-0 flex flex-col gap-2 text-sm text-gray-600">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2" title="Data de Adição">
              <Clock className="w-4 h-4 text-gray-400" />
              <span>Adicionado em: <b>{formattedAddedDate}</b></span>
            </div>
          </div>
          
          {product.barcode && (
            <div className="flex items-center gap-2" title="Código de Barras">
              <Tag className="w-4 h-4 text-gray-400" />
              <span className="font-mono bg-gray-100 px-1.5 py-0.5 rounded text-xs tracking-wider text-gray-700">
                {product.barcode}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};