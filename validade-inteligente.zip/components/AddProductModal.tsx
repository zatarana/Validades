import React, { useState, useEffect, useRef } from 'react';
import { X, Camera, Search, Loader2, Sparkles, ScanLine, StopCircle, Image as ImageIcon, UploadCloud } from 'lucide-react';
import { identifyProductByBarcode, identifyProductByImage } from '../services/gemini';
import { Product } from '../types';
import { Html5Qrcode } from 'html5-qrcode';

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (product: Omit<Product, 'id' | 'addedAt'>) => void;
}

export const AddProductModal: React.FC<AddProductModalProps> = ({ isOpen, onClose, onAdd }) => {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('');
  
  const [isIdentifying, setIsIdentifying] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // We need a ref to track the scanner instance for cleanup
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Cleanup scanner when modal closes or unmounts
    return () => {
      if (scannerRef.current) {
        if (scannerRef.current.isScanning) {
          scannerRef.current.stop().catch(console.error);
        }
        scannerRef.current.clear();
        scannerRef.current = null;
      }
    };
  }, []);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !date) {
      setError('Nome e data são obrigatórios');
      return;
    }
    
    onAdd({
      name,
      expirationDate: date,
      barcode,
      category,
      quantity: 1, // Default quantity
    });
    
    // Reset
    setName('');
    setDate('');
    setBarcode('');
    setCategory('');
    setError(null);
    setIsScanning(false);
    onClose();
  };

  const handleIdentify = async (codeToSearch?: string) => {
    const code = codeToSearch || barcode;
    if (!code) {
      setError('Insira um código de barras para pesquisar.');
      return;
    }
    
    setIsIdentifying(true);
    setError(null);

    try {
      const result = await identifyProductByBarcode(code);
      if (result) {
        setName(result.name);
        setCategory(result.category);
      } else {
        setError('Produto não encontrado na base de dados de IA.');
      }
    } catch (err) {
      setError('Erro ao conectar com a IA.');
    } finally {
      setIsIdentifying(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size (limit to 5MB roughly)
    if (file.size > 5 * 1024 * 1024) {
      setError("A imagem é muito grande. Tente uma menor.");
      return;
    }

    setIsIdentifying(true);
    setError(null);

    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const base64String = reader.result as string;
        const result = await identifyProductByImage(base64String);
        
        if (result) {
          setName(result.name);
          setCategory(result.category);
        } else {
          setError("Não foi possível identificar o produto na imagem.");
        }
      } catch (err) {
        console.error(err);
        setError("Erro ao processar imagem.");
      } finally {
        setIsIdentifying(false);
        // Reset input value to allow selecting same file again if needed
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsDataURL(file);
  };

  const triggerImageSelect = () => {
    fileInputRef.current?.click();
  };

  const startScanner = () => {
    setIsScanning(true);
    setError(null);
    
    // Small delay to ensure the DOM element exists
    setTimeout(() => {
      const html5QrCode = new Html5Qrcode("reader");
      scannerRef.current = html5QrCode;

      const config = { fps: 10, qrbox: { width: 250, height: 250 } };
      
      html5QrCode.start(
        { facingMode: "environment" }, 
        config,
        (decodedText) => {
          // Success callback
          setBarcode(decodedText);
          stopScanner();
          // Automatically trigger identification
          handleIdentify(decodedText);
        },
        (errorMessage) => {
          // Parse error, ignore for UI cleanliness
        }
      ).catch((err) => {
        console.error(err);
        setError("Erro ao iniciar a câmera. Verifique as permissões.");
        setIsScanning(false);
      });
    }, 100);
  };

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.stop().then(() => {
        scannerRef.current?.clear();
        setIsScanning(false);
      }).catch(err => console.error("Failed to stop scanner", err));
    } else {
      setIsScanning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 max-h-[90vh] overflow-y-auto">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-brand-600" />
            Adicionar Produto
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 text-gray-500 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Scanner UI Overlay */}
          {isScanning && (
            <div className="mb-4 bg-black rounded-lg overflow-hidden relative">
               <div id="reader" className="w-full h-64"></div>
               <button 
                 type="button" 
                 onClick={stopScanner}
                 className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white/20 backdrop-blur-md text-white px-4 py-2 rounded-full flex items-center gap-2 hover:bg-white/30 transition-colors z-10"
               >
                 <StopCircle className="w-5 h-5" />
                 Cancelar Scanner
               </button>
            </div>
          )}

          {/* Identification Options */}
          {!isScanning && (
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={startScanner}
                className="flex flex-col items-center justify-center p-3 border border-dashed border-gray-300 rounded-xl bg-gray-50 hover:bg-gray-100 hover:border-brand-400 transition-all gap-2 group"
              >
                <div className="p-2 bg-white rounded-full shadow-sm group-hover:scale-110 transition-transform">
                  <ScanLine className="w-5 h-5 text-brand-600" />
                </div>
                <span className="text-xs font-medium text-gray-600">Ler Código</span>
              </button>

              <button
                type="button"
                onClick={triggerImageSelect}
                disabled={isIdentifying}
                className="flex flex-col items-center justify-center p-3 border border-dashed border-gray-300 rounded-xl bg-gray-50 hover:bg-gray-100 hover:border-brand-400 transition-all gap-2 group disabled:opacity-50"
              >
                <div className="p-2 bg-white rounded-full shadow-sm group-hover:scale-110 transition-transform">
                  {isIdentifying ? <Loader2 className="w-5 h-5 text-brand-600 animate-spin" /> : <ImageIcon className="w-5 h-5 text-brand-600" />}
                </div>
                <span className="text-xs font-medium text-gray-600">
                  {isIdentifying ? 'Analisando...' : 'Identificar por Foto'}
                </span>
                <input 
                  type="file" 
                  accept="image/*" 
                  ref={fileInputRef} 
                  className="hidden" 
                  onChange={handleImageUpload}
                />
              </button>
            </div>
          )}

          {/* Barcode Manual Entry */}
          {!isScanning && (
          <div className="space-y-1">
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide">Código de Barras (Opcional)</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                placeholder="00000000000"
                className="flex-1 px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
              />
              <button
                type="button"
                onClick={() => handleIdentify()}
                disabled={isIdentifying || !barcode}
                className="px-4 py-2 bg-white border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-colors shadow-sm"
                title="Pesquisar código"
              >
                {isIdentifying && barcode ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              </button>
            </div>
          </div>
          )}

          <hr className="border-gray-100" />

          {/* Name */}
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">Nome do Produto</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Leite Integral"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
            />
          </div>

          {/* Category */}
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">Categoria</label>
            <input
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              placeholder="Ex: Laticínios"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
            />
          </div>

          {/* Expiration Date */}
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">Data de Validade</label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
            />
          </div>

          {error && (
            <div className="p-3 bg-red-50 text-red-700 text-sm rounded-lg flex items-center gap-2 animate-in slide-in-from-top-1">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          )}

          <div className="pt-2 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 font-medium transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-brand-600 text-white rounded-xl hover:bg-brand-700 font-medium shadow-lg shadow-brand-200 transition-all hover:shadow-xl hover:-translate-y-0.5"
            >
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Helper icon
const AlertTriangle: React.FC<{className?:string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
);