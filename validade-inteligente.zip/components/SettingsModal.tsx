import React, { useRef, useState } from 'react';
import { X, Save, Upload, Trash2, AlertTriangle, Check, Info } from 'lucide-react';
import { Product } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onImport: (products: Product[]) => void;
  onClear: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, products, onImport, onClear }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');

  if (!isOpen) return null;

  const handleExportBackup = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(products));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "validade_ai_backup.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (Array.isArray(json)) {
          // Basic validation could go here
          onImport(json);
          setImportStatus('success');
          setTimeout(() => setImportStatus('idle'), 3000);
        } else {
          setImportStatus('error');
        }
      } catch (err) {
        setImportStatus('error');
      }
    };
    reader.readAsText(file);
    // Reset input
    e.target.value = '';
  };

  const handleClearAll = () => {
    if (window.confirm('ATENÇÃO: Isso apagará TODOS os produtos cadastrados. Esta ação não pode ser desfeita. Deseja continuar?')) {
      onClear();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            Configurações
          </h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 text-gray-500 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Backup Section */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Gerenciar Dados</h3>
            
            <button 
              onClick={handleExportBackup}
              className="w-full flex items-center justify-between p-4 bg-blue-50 text-blue-700 rounded-xl hover:bg-blue-100 transition-colors border border-blue-100"
            >
              <div className="flex items-center gap-3">
                <Save className="w-5 h-5" />
                <div className="text-left">
                  <div className="font-semibold">Fazer Backup</div>
                  <div className="text-xs opacity-80">Salvar dados em arquivo .json</div>
                </div>
              </div>
            </button>

            <button 
              onClick={handleImportClick}
              className="w-full flex items-center justify-between p-4 bg-gray-50 text-gray-700 rounded-xl hover:bg-gray-100 transition-colors border border-gray-200"
            >
              <div className="flex items-center gap-3">
                <Upload className="w-5 h-5" />
                <div className="text-left">
                  <div className="font-semibold">Restaurar Backup</div>
                  <div className="text-xs opacity-80">Carregar dados de arquivo .json</div>
                </div>
              </div>
              {importStatus === 'success' && <Check className="w-5 h-5 text-green-500" />}
              {importStatus === 'error' && <AlertTriangle className="w-5 h-5 text-red-500" />}
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              accept=".json" 
              className="hidden" 
            />
            {importStatus === 'error' && (
              <p className="text-xs text-red-500 text-center">Arquivo inválido. Certifique-se de usar um backup deste app.</p>
            )}
          </section>

          <hr className="border-gray-100" />

          {/* Danger Zone */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-red-500 uppercase tracking-wider">Zona de Perigo</h3>
            <button 
              onClick={handleClearAll}
              className="w-full flex items-center gap-3 p-4 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors border border-red-100"
            >
              <Trash2 className="w-5 h-5" />
              <div className="font-semibold">Apagar Tudo</div>
            </button>
          </section>

          <hr className="border-gray-100" />

          <div className="text-center">
            <p className="text-xs text-gray-400 flex items-center justify-center gap-1">
              <Info className="w-3 h-3" />
              Versão PWA 1.0.0
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};