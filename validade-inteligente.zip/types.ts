export interface Product {
  id: string;
  name: string;
  expirationDate: string; // YYYY-MM-DD
  barcode?: string;
  category?: string;
  imageUrl?: string;
  addedAt: number;
  quantity: number;
}

export enum SortOption {
  EXPIRATION_ASC = 'EXPIRATION_ASC', // Closest to furthest
  EXPIRATION_DESC = 'EXPIRATION_DESC',
  NAME_ASC = 'NAME_ASC',
  ADDED_DATE_DESC = 'ADDED_DATE_DESC',
}

export enum FilterStatus {
  ALL = 'ALL',
  EXPIRED = 'EXPIRED',
  WARNING = 'WARNING', // < 7 days
  GOOD = 'GOOD',
}

export interface ProductSuggestion {
  name: string;
  category: string;
}